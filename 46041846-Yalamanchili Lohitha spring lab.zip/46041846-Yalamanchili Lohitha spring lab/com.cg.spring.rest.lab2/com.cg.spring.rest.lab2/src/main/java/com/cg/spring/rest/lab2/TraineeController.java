package com.cg.spring.rest.lab2;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

//mark class as Controller
@RestController
public class TraineeController {
//autowire the EmployeeService class 
	@Autowired
	TraineeService traineeService;

//creating a get mapping that retrieves all the Trainee detail from the database
	@GetMapping("/Trainee")
	private List<Trainee> getAllTrainee() {
		return traineeService.getAllTrainee();
	}
	
	
	//creating a get mapping that retrieves the detail of a specific Trainee
	@GetMapping("/Trainee/{traineeName}")
	private List<Trainee> getTraineeByName(@PathVariable("traineeName") String traineeName) {
		return traineeService.getTraineeByName(traineeName);
	}
	
	
//creating a get mapping that retrieves the detail of a specific Trainee
	@GetMapping("/Trainee/{traineeId}")
	private List<Trainee> getTrainee(@PathVariable("traineeId") int traineeId) {
		return traineeService.getTraineeById(traineeId);
	}

	
//creating a delete mapping that deletes a specified Trainee
	@DeleteMapping("/Trainee/{traineeId}")
	private void deleteTrainee(@PathVariable("traineeId") int traineeId) {
		traineeService.delete(traineeId);
	}

	
//creating post mapping that post the Trainee detail in the database
	@PostMapping("/Trainee")
	private int saveTrainee(@RequestBody Trainee Trainee) {
		traineeService.saveOrUpdate(Trainee);
		return Trainee.getTraineeId();
	}

	
//creating put mapping that updates the Trainee detail
	@PutMapping("/Trainee")
	private Trainee update(@RequestBody Trainee Trainee) {
		traineeService.saveOrUpdate(Trainee);
		return Trainee;
	}
	
	
}