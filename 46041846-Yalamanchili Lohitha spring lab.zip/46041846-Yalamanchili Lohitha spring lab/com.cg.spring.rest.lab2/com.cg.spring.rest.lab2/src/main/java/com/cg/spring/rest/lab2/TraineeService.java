package com.cg.spring.rest.lab2;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
//defining the business logic
@Service
public class TraineeService {
 	@Autowired
 	TraineJpaRepository traineeRepo;
 
//getting all Trainee record by using the method findaAll() of CrudRepository
 	public List<Trainee> getAllTrainee() {
       	List<Trainee> trainee = new ArrayList<Trainee>();
       	traineeRepo.findAll().forEach(trainee1 -> trainee.add(trainee1));
       	return trainee;
 	}
 
//getting a specific record by using the method findById() of CrudRepository
 	public List<Trainee> getTraineeByName(String traineeName) {
 		List<Trainee> trainee = new ArrayList<Trainee>();
       	traineeRepo.findAll().forEach(trainee1 -> trainee.add(trainee1));
		return trainee;
 	}
 	
//getting a specific record by using the method findById() of CrudRepository
 	 	public List<Trainee> getTraineeById(int traineeId) {
 	 		List<Trainee> trainee = new ArrayList<Trainee>();
 	       	traineeRepo.findAll().forEach(trainee1 -> trainee.add(trainee1));
 			return trainee;
 	 	}
 	  	
 
//saving a specific record by using the method save() of CrudRepository
 	public void saveOrUpdate(Trainee trainee) {
       	traineeRepo.save(trainee);
 	}
 
//deleting a specific record by using the method deleteById() of CrudRepository
 	public void delete(int id) {
       	traineeRepo.deleteById(id);
 	}
 
//updating a record
 	public void update(Trainee trainee, int eid) {
       	traineeRepo.save(trainee);
 	}
}