package com.cg.spring.lab3;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Movies {
	
	@Id
	@Column
	private String movieName;
	@Column
	private double ratings; 
	@Column
	private String genre;
	
	
	
	
	public Movies() {
		super();
	}


	public Movies(String movieName, double ratings, String genre) {
		super();
		this.movieName = movieName;
		this.ratings = ratings;
		this.genre = genre;
	}


	public String getMovieName() {
		return movieName;
	}


	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}


	public double getRatings() {
		return ratings;
	}


	public void setRatings(double ratings) {
		this.ratings = ratings;
	}


	public String getGenre() {
		return genre;
	}


	public void setGenre(String genre) {
		this.genre = genre;
	}


	@Override
	public String toString() {
		return "Movies [movieName=" + movieName + ", ratings=" + ratings + ", genre=" + genre + "]";
	}
	
	

}
