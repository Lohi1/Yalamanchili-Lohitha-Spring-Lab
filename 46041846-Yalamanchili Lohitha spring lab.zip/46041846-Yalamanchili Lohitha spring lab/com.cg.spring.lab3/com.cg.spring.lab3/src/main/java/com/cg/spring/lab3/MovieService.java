package com.cg.spring.lab3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MovieService {
	@Autowired
	MovieRepository movieRepository;

	public List<Movies> getAllMovies() {
		List<Movies> movies=new ArrayList<Movies>();
		movieRepository.findAll().forEach(movie1->movies.add(movie1));
		return movies;
		
	}

	public void deleteMovie(String movieName) {
		movieRepository.deleteById(movieName);	
	}

	public List<Movies> getMoviesByGenre(String genre) {
		List<Movies> movies=new ArrayList<Movies>();
		movieRepository.findAll().forEach(movie1->movies.add(movie1));
		List<Movies> genreBasedMovies=new ArrayList<Movies>();
		for(Movies m:movies)
		{
			if(m.getGenre().equals(genre))
				genreBasedMovies.add(m);	
		}
		return genreBasedMovies;
	}

	public void insertMovie(Movies movie) {
		movieRepository.save(movie);
	}

	public Movies updateMovie(Movies movie) {
		// TODO Auto-generated method stub
		return movieRepository.save(movie);
	}

}
